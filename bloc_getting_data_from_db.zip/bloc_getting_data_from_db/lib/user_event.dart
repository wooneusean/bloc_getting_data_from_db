abstract class UserEvent {}
class LoadUserEvent extends UserEvent{}